# Belegt-Prüfpaket (req_4YYTHZ15QSRSER4811J3XJ69MR)

Format `belegt-auditpack/1` (Designdokument 03 §7). Prüfschritte:

1. `belegt-calc verify-pack <zip>` – Signatur von `manifest.json` (`manifest.sig`, Ed25519) und alle Datei-Hashes prüfen; `pack_hash = sha256(JCS(files))`.
2. Für jede Datei `calculations/replay/*.json` `input_hash` aus `m` (RFC 8785 JCS + SHA-256) und `output_hash` aus `result` + `breakdown` neu berechnen.
3. Jede freigegebene/übermittelte Zahlenantwort muss Evidenz oder eine Berechnung referenzieren (R-NUM) und deren Wert exakt tragen (R-VAL).
4. `audit_chain_proof.json` + `audit_events.jsonl`: `event_hash = sha256(prev_hash || JCS(Ereignis ohne event_hash))`, lückenlose `seq`.

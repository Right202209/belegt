# Belegt audit pack (req_4YYTHZ15QSRSER4811J3XJ69MR)

Format `belegt-auditpack/1` (Belegt design doc 03 §7). Verification:

1. `belegt-calc verify-pack <zip>` – checks the manifest signature (`manifest.sig`, Ed25519) and every file hash; `pack_hash = sha256(JCS(files))`.
2. For each `calculations/replay/*.json`, recompute `input_hash` from `m` (RFC 8785 JCS + SHA-256) and `output_hash` from the calculation's `result` + `breakdown`.
3. Every `approved`/`submitted` number answer must cite evidence or a calculation (R-NUM) and equal the cited value (R-VAL).
4. `audit_chain_proof.json` + `audit_events.jsonl`: `event_hash = sha256(prev_hash || JCS(event without event_hash))`, consecutive `seq`.
